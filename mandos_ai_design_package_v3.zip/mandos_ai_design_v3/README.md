# Mandos-AI Design Package v3

This package rebuilds the Mandos-AI design and implementation documents with the latest design constraints:

- high-level design only; development AI maps to current Mandos APIs
- no stale table/method/report assumptions
- Model Knowledge Packs for model-specific Markdown context
- source discipline: context vs policy vs evidence vs implementation
- Copilot customization architecture: instructions, agents, skills, prompts, templates, validation, MCP later
- phased implementation across milestones, epics, stories, and Staff+ prompts

Files:

- mandos_ai_full_design_v3.md
- mandos_ai_phased_implementation_plan_v3.md
- mandos_model_knowledge_pack_standard_v3.md
- mandos_ai_agents_skills_prompts_mcp_design_v3.md
- mandos_ai_staff_prompt_library_v3.md
- templates/model_knowledge_pack/*.md
