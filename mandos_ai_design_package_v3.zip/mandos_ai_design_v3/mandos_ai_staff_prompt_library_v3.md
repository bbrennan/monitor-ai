# Mandos-AI Staff+ Prompt Library v3

**Status:** Draft  
**Purpose:** Reusable prompts for the development AI implementing Mandos-AI.


## Master Implementation Prompt

```text
You are implementing Mandos-AI, an internal GitHub Copilot customization package for the Mandos model monitoring library.

Critical constraints:
- Inspect the current Mandos codebase before using any method names, schemas, table names, config fields, or report APIs.
- The design docs define goals and workflows. The repo defines implementation specifics.
- Do not hardcode stale assumptions.
- Mandos-AI must never report model-specific facts from memory.
- Markdown docs provide context, active configs provide policy, generated Mandos outputs and approved persisted evidence provide observed facts, and code definitions provide implementation truth.
- Use FACT / INTERPRETATION / RECOMMENDATION when explaining evidence.
- Keep implementation small and purposeful.
- Follow KISS, YAGNI, and clarity over cleverness.
```

## Prompt: Create Repo Instructions

```text
Create `.github/copilot-instructions.md` for Mandos-AI. Include evidence rules, source hierarchy, implementation note to inspect current APIs, KISS/YAGNI/clarity principles, no secrets/raw data examples, and alert triage principles. Keep concise.
```

## Prompt: Create Model Knowledge Pack Templates

```text
Create Markdown templates for the Model Knowledge Pack. Each template must include standard frontmatter and sections: Purpose, Required Facts, Business / Technical Explanation, Monitoring Implications, Open Questions, Review Checklist. Use placeholders only.
```

## Prompt: Guided Intake

```text
Create a guided model-owner intake prompt. Ask for information in stages: identity, business purpose, population, target, score, data sources, features, preprocessing, baseline, segmentation, monitoring plan, limitations, validation context, open questions. Track missing facts and label assumptions.
```

## Prompt: Starter Agent

```text
Create the initial `mandos-analyst` agent. It should help with onboarding, Model Knowledge Pack creation, setup guidance, report explanation, alert triage, validation summaries, and custom report planning. Keep it concise and delegate workflows to skills/prompts. No broad tools or stale assumptions.
```

## Prompt: Core Skills

```text
Create skills for Model Knowledge Pack, setup, report explanation, alert triage, validation evidence, and custom reporting. Each skill must include Purpose, When to Use, Inputs Required, Workflow, Output Format, Evidence Rules, Examples, and Do Not.
```

## Prompt: Report Explainer

```text
Implement the report explainer workflow. Require a generated report/result artifact or excerpt. Never invent metric values. Use FACT / INTERPRETATION / RECOMMENDATION. Classify findings into Action Required, Watchlist, Informational, and Likely Noise. Flag unsupported claims.
```

## Prompt: Alert Triage

```text
Implement the alert triage workflow. Classify findings by materiality, persistence, affected volume, segment/feature importance, known limitations, and business relevance. Suppression must be transparent and included in output.
```

## Prompt: AI Asset Validation

```text
Create a lightweight validation script for agents, skills, prompts, and Model Knowledge Pack templates. Check required frontmatter/sections, obvious secrets, raw data examples, and presence of evidence rules. Avoid heavy dependencies.
```

## Prompt: MCP Design Only

```text
Create a design-only MCP document. Do not implement unless requested. Define purpose, non-goals, tool tiers, read-only tools, analysis tools, write tools requiring confirmation, provenance metadata, raw-data restrictions, failure handling, and phased rollout. Do not assume current Mandos persistence details.
```

## Prompt: Milestone Review

```text
Review the current Mandos-AI milestone implementation. Assess acceptance criteria, source discipline, stale assumptions, consistency, complexity, missing sections, and readiness for the next milestone. Output Pass/Needs Work, Findings, Required Fixes, Suggested Improvements, Risks, and Next Milestone Readiness.
```
