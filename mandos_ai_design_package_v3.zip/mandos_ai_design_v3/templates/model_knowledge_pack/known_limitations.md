---
model_id: ""
model_version: ""
document_type: "known_limitations"
status: "draft"
owner: ""
last_updated: ""
source: "model_owner_input"
reviewed_by: ""
review_status: "not_reviewed"
---

# Known Limitations

## Purpose

Describe why this document exists and how Mandos-AI should use it.

## Required Facts

- TODO

## Business / Technical Explanation

- TODO

## Monitoring Implications

Explain how this information should influence Mandos monitoring interpretation, report explanation, alert triage, or validation evidence.

## Open Questions

- TODO

## Review Checklist

- [ ] Required facts are complete.
- [ ] Assumptions are labeled.
- [ ] Open questions are listed.
- [ ] Information is consistent with active configs where applicable.
- [ ] Information has been reviewed by the model owner.
