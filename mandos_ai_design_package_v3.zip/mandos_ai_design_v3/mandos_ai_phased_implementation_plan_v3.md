# Mandos-AI Phased Implementation Plan v3

**Status:** Draft  
**Purpose:** Epics, milestones, stories, and Staff+ implementation prompts.


## Implementation Note for the Development AI

These documents intentionally avoid hardcoding Mandos method names, object schemas, table names, report APIs, and persistence-layer details. The development AI implementing this work must inspect the current Mandos codebase and map these designs to the latest available APIs, config models, reporting interfaces, result objects, persistence objects, and tests.

The docs are authoritative about **goals, workflows, evidence rules, user experience, and architectural boundaries**. The current repo is authoritative about **exact implementation details**.


## Implementation Strategy

Build Mandos-AI in small milestones. Do not one-shot a large agent system.

Recommended order:

1. Evidence doctrine and repo-level instructions
2. Model Knowledge Pack standard and templates
3. Guided model-owner intake prompts
4. Single starter Mandos Analyst agent
5. Core skills and prompt files
6. Zuul 2.0 pilot package
7. Report explainer and validation summary workflow
8. Alert triage workflow
9. Custom reporting workflow
10. AI asset validation
11. MCP design/prototype if approved
12. Future multi-agent split

## Milestone 0 — Design Package Accepted

### Key Tasks
- Review v3 docs
- Confirm evidence doctrine
- Confirm no stale implementation assumptions
- Approve initial scope

### Acceptance Criteria
- Docs reviewed
- Implementation scope accepted
- Dev AI prompt ready

## Milestone 1 — Repo-Level Foundation

### Key Tasks
- Create `.github/copilot-instructions.md`
- Create doctrine/source hierarchy docs
- Create FACT/INTERPRETATION/RECOMMENDATION guidance

### Acceptance Criteria
- Copilot instructions exist
- Evidence rules are clear
- No stale implementation specifics

## Milestone 2 — Model Knowledge Pack Standard

### Key Tasks
- Create documentation standard
- Create required Markdown templates
- Define frontmatter and review statuses

### Acceptance Criteria
- Templates complete
- Required sections present
- Docs distinguish context from evidence

## Milestone 3 — Guided Onboarding Workflow

### Key Tasks
- Create guided intake prompt
- Create review prompt
- Create onboarding checklist

### Acceptance Criteria
- User can answer step-by-step
- Draft docs can be generated
- Missing facts are tracked

## Milestone 4 — Starter Mandos Analyst Agent

### Key Tasks
- Create `mandos-analyst.agent.md`
- Keep tool scope safe
- Delegate details to skills/prompts

### Acceptance Criteria
- Agent handles onboarding/report/triage questions
- Agent does not invent facts
- Agent avoids stale API assumptions

## Milestone 5 — Core Skills and Prompt Library

### Key Tasks
- Create setup skill
- Create Model Knowledge Pack skill
- Create report explainer skill
- Create alert triage skill
- Create validation evidence skill

### Acceptance Criteria
- Skills have consistent sections
- Prompts are reusable
- Evidence rules are embedded

## Milestone 6 — Zuul 2.0 Pilot Package

### Key Tasks
- Create model-specific pilot docs if approved
- Apply templates to Zuul input
- Capture lessons learned

### Acceptance Criteria
- Zuul docs are draft/reviewed as appropriate
- Generic templates remain generic
- Pilot improves validation support

## Milestone 7 — Report Explainer and Validation Workflow

### Key Tasks
- Create report explainer prompt/skill
- Create validation summary template
- Create example report summary

### Acceptance Criteria
- Outputs use FACT/INTERPRETATION/RECOMMENDATION
- Unsupported claims flagged
- Validation summary is usable

## Milestone 8 — Alert Triage Workflow

### Key Tasks
- Create triage skill
- Create triage prompt
- Create alert triage report template

### Acceptance Criteria
- Findings classified into action/watchlist/info/suppressed
- Suppression rationale included
- No silent hiding

## Milestone 9 — Custom Reporting Workflow

### Key Tasks
- Create custom reporting skill
- Create report templates
- Create chart recipe catalog

### Acceptance Criteria
- Audience/purpose captured
- Evidence inventory step required
- Chart recommendations are evidence-dependent

## Milestone 10 — AI Asset Validation

### Key Tasks
- Create validation script
- Create catalog builder
- Add project command

### Acceptance Criteria
- Agents/skills/prompts/templates validated
- No obvious secrets
- Required sections checked

## Milestone 11 — MCP Readiness

### Key Tasks
- Create MCP design doc
- Create MCP evidence querying skill
- Prototype only if approved

### Acceptance Criteria
- Read-only first
- No arbitrary raw data access
- Tool output provenance defined

## Milestone 12 — Future Multi-Agent Split

### Key Tasks
- Create agent split design
- Add specialized agents only if needed

### Acceptance Criteria
- Roles clear
- Tool boundaries clear
- Handoffs documented


## Epic 1 — Evidence Doctrine and Source Discipline

### Story 1.1 — Create evidence doctrine

**As a** Mandos-AI user, **I want** the assistant to distinguish facts from interpretations and recommendations, **so that** I can trust its outputs.

Acceptance criteria:

- Defines facts, interpretations, and recommendations.
- Defines source hierarchy.
- Includes examples.
- Says never report model-specific facts from memory.

Staff+ prompt:

```text
You are implementing Mandos-AI evidence doctrine. Create durable documentation explaining that Mandos-AI must never report model-specific facts from memory. Define source classes, source hierarchy, FACT / INTERPRETATION / RECOMMENDATION, conflict handling, and examples. Do not hardcode stale Mandos APIs or table names. Inspect the current repo only when implementation-specific examples are needed. Keep the docs clear, concise, and enforceable.
```

### Story 1.2 — Add repo-level Copilot instructions

Acceptance criteria:

- Adds always-on Copilot guidance.
- Includes no metric -> no claim.
- Includes inspect-current-codebase instruction.
- Includes no secrets/raw customer data reminders.

Staff+ prompt:

```text
Create `.github/copilot-instructions.md` for Mandos-AI. It should guide all Copilot activity in this repo with evidence rules, source hierarchy, KISS/YAGNI/clarity principles, no stale API assumptions, and no raw production data or secrets in examples. Keep it concise and practical.
```


## Epic 2 — Model Knowledge Pack Standard

### Story 2.1 — Define required model documentation

Acceptance criteria:

- Defines must-have docs.
- Defines optional docs.
- Defines frontmatter and review states.
- Explains how Mandos-AI uses docs as context.

Staff+ prompt:

```text
Design the Mandos Model Knowledge Pack standard. Define required Markdown artifacts, required frontmatter, review statuses, required sections, model owner inputs, and how these docs differ from active configs and generated monitoring evidence. Include must-have topics: model identity, business purpose, scored population, data sources, target definition, score definition, features, preprocessing, quality policy, baseline, segmentation, monitoring plan, proxy metrics, known limitations, validation context, and open questions. Avoid stale Mandos implementation assumptions.
```

### Story 2.2 — Create Markdown templates

Staff+ prompt:

```text
Create Markdown templates for the full Model Knowledge Pack. Each template must include frontmatter and the sections Purpose, Required Facts, Business / Technical Explanation, Monitoring Implications, Open Questions, and Review Checklist. Do not include real model facts. Use placeholders.
```


## Epic 3 — Guided Onboarding Workflow

### Story 3.1 — Create guided intake prompt

Staff+ prompt:

```text
Create a GitHub Copilot prompt file that guides model owners through Model Knowledge Pack intake in stages. It should ask for model identity, business purpose, population, target, score, data sources, features, preprocessing, baseline, segmentation, monitoring plan, limitations, validation context, and open questions. It must avoid asking everything at once, must label assumptions, must track missing facts, and must never invent model facts.
```

### Story 3.2 — Create Knowledge Pack review prompt

Staff+ prompt:

```text
Create a reusable prompt to review a draft Model Knowledge Pack for completeness, conflicts, unsupported facts, draft assumptions, missing sections, unclear target/score definitions, weak monitoring implications, and open validation questions. Output readiness status, required fixes, and suggested follow-up questions.
```


## Epic 4 — Starter Agent and Skills

### Story 4.1 — Create `mandos-analyst` starter agent

Staff+ prompt:

```text
Create the initial `mandos-analyst` custom agent. It is the only agent to implement initially. It should help with onboarding, Model Knowledge Pack creation, setup guidance, generated report explanation, alert triage, validation summaries, and custom report planning. Keep it concise and delegate detailed workflows to skills/prompts. It must never invent model-specific facts, must avoid stale Mandos API assumptions, and must not include broad raw-data or write tools.
```

### Story 4.2 — Create core skills

Staff+ prompt:

```text
Create the first Mandos-AI skills: mandos-model-knowledge-pack, mandos-setup, mandos-report-explainer, mandos-alert-triage, mandos-validation-evidence, and mandos-custom-reporting. Each skill must include Purpose, When to Use, Inputs Required, Workflow, Output Format, Evidence Rules, Examples, and Do Not. Keep them implementation-agnostic and instruct future agents to inspect the current Mandos APIs when code is needed.
```


## Epic 5 — Report Explanation, Alert Triage, and Custom Reporting

### Story 5.1 — Report explainer workflow

Staff+ prompt:

```text
Implement the Mandos-AI report explainer workflow. Create the skill, prompt, and validation evidence summary template. The workflow must require a generated report/result artifact or user-provided excerpt, avoid inventing metric values, separate FACT / INTERPRETATION / RECOMMENDATION, classify findings by action/watchlist/info/noise, and flag unsupported claims.
```

### Story 5.2 — Alert triage workflow

Staff+ prompt:

```text
Implement the alert triage workflow. Create the skill, prompt, and alert triage summary template. Classify findings as Action Required, Watchlist, Informational, or Suppressed / Likely Noise. Use severity, persistence, materiality, affected volume, feature/segment importance, business relevance, known limitations, and likely shared root cause. Suppression must be transparent.
```

### Story 5.3 — Custom reporting workflow

Staff+ prompt:

```text
Implement the custom reporting workflow. Create a skill, prompt, report templates, and chart recipe catalog. The workflow should ask for audience and purpose, inventory available evidence, propose report structure and charts, generate templates/scripts using current Mandos APIs, and flag unsupported factual claims. Custom reports do not replace standard Mandos reports.
```


## Epic 6 — AI Asset Validation

Staff+ prompt:

```text
Create a lightweight AI asset validation script. Validate that agent files have frontmatter, skill folders contain SKILL.md, skills include required sections, prompts include purpose/input/output guidance, Model Knowledge Pack templates include required frontmatter and sections, and obvious secrets/raw data examples are absent. Add a simple project command aligned to current repo conventions. Do not introduce unnecessary dependencies.
```


## Epic 7 — MCP Readiness

Staff+ prompt:

```text
Create a design-only MCP document for Mandos-AI. Do not implement MCP unless explicitly requested. Define purpose, non-goals, tool safety tiers, candidate read-only tools, candidate analysis tools, candidate write tools requiring confirmation, source/provenance metadata, authentication/authorization considerations, raw data restrictions, failure handling, and rollout plan. Do not assume current Mandos persistence details. The implementation agent must inspect the current Mandos evidence layer.
```


## Recommended First Four Sprints

### Sprint 1 — Foundation

- Evidence doctrine
- Source hierarchy
- Repo-level Copilot instructions
- Model Knowledge Pack standard

### Sprint 2 — Model Documentation Templates

- Required Markdown templates
- Guided intake prompt
- Review prompt
- Onboarding checklist

### Sprint 3 — Starter Agent and Skills

- `mandos-analyst` agent
- Model Knowledge Pack skill
- Setup skill
- Report explainer skill

### Sprint 4 — Report and Triage Workflows

- Validation summary template
- Alert triage skill/prompt/template
- Custom reporting design scaffold
- AI asset validation plan


## Do-Not List

The development AI must not:

- hardcode stale Mandos APIs, schemas, tables, or report objects
- assume persistence details not present in the current repo
- invent metric values or conclusions
- treat draft Markdown docs as production truth
- silently resolve config/doc/report conflicts
- expose raw customer-level data in examples
- create arbitrary SQL MCP access
- implement all future agents in one pass
- overcomplicate v0.1
