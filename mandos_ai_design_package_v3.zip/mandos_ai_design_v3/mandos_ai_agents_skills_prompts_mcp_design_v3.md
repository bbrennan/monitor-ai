# Mandos-AI Agents, Skills, Prompts, and MCP Design v3

**Status:** Draft  
**Purpose:** Copilot customization architecture and controlled tooling plan.


## Implementation Note for the Development AI

These documents intentionally avoid hardcoding Mandos method names, object schemas, table names, report APIs, and persistence-layer details. The development AI implementing this work must inspect the current Mandos codebase and map these designs to the latest available APIs, config models, reporting interfaces, result objects, persistence objects, and tests.

The docs are authoritative about **goals, workflows, evidence rules, user experience, and architectural boundaries**. The current repo is authoritative about **exact implementation details**.

## Design Thesis

Mandos-AI should be implemented as a maintainable Copilot customization package: instructions, agents, skills, prompt files, templates, validation scripts, and optional MCP tools. Start with one agent and grow only when usage patterns justify it.

## Initial Asset Set

- `.github/copilot-instructions.md`
- `.github/agents/mandos-analyst.agent.md`
- `.github/skills/mandos-model-knowledge-pack/SKILL.md`
- `.github/skills/mandos-setup/SKILL.md`
- `.github/skills/mandos-report-explainer/SKILL.md`
- `.github/skills/mandos-alert-triage/SKILL.md`
- `.github/prompts/mandos-create-model-knowledge-pack.prompt.md`
- `.github/prompts/mandos-explain-report.prompt.md`
- `.github/prompts/mandos-triage-alerts.prompt.md`
- Model Knowledge Pack templates
- AI asset validator

## Agent Responsibilities

### mandos-analyst

Primary early agent. Helps with onboarding, documentation, setup guidance, report explanation, alert triage, and validation summaries. Safe tool scope only.

### mandos-config-architect

Future setup/config specialist. Reviews setup artifacts, quality policies, baselines, and segmentation.

### mandos-report-builder

Future reporting specialist. Creates custom report outlines, charts, scripts, and templates.

### mandos-validation-reviewer

Future evidence-quality specialist. Checks if facts support validation claims and identifies open risks.

### mandos-monitoring-analyst

Future historical analysis specialist. Uses controlled evidence tools to answer trend/recurrence/change questions.

### mandos-engineer

Future implementation specialist. Updates code/tests/docs and inspects current APIs. No production data access.

## Skill Contract

Every skill should include:

- Purpose
- When to Use
- Inputs Required
- Workflow
- Output Format
- Evidence Rules
- Examples
- Do Not

## Core Skills

### mandos-model-knowledge-pack

Guides model owner intake and creates standardized docs.

### mandos-setup

Guides setup at a high level and tells dev AI to map to current Mandos APIs.

### mandos-report-explainer

Explains generated report/result artifacts using sourced facts.

### mandos-alert-triage

Classifies findings into action/watchlist/info/suppressed and reduces alert fatigue.

### mandos-validation-evidence

Creates validation-ready summaries with assumptions, limitations, and appendix evidence.

### mandos-custom-reporting

Creates audience-specific report outlines and chart recommendations.

### mandos-mcp-evidence-querying

Future skill for safe controlled tool usage.

## Prompt Files

Prompt files should make common workflows repeatable:

- create Model Knowledge Pack
- review Model Knowledge Pack
- create setup scaffold
- review setup
- explain report
- triage alerts
- create validation summary
- create custom report

## MCP Principles

MCP is optional and future-facing. It should expose controlled evidence tools, not arbitrary data access.

### Non-goals

- no arbitrary SQL
- no broad raw customer data access
- no production writes initially
- no baseline creation without confirmation
- no official report persistence without confirmation

### Tool Tiers

Tier 1 — Read-only evidence/config/artifact retrieval.

Tier 2 — Analysis over approved evidence.

Tier 3 — Write/official actions requiring explicit confirmation and audit logging.

### Tool Output Requirements

Every tool output should include source type, source identifier, retrieval timestamp, model identifier if applicable, completeness/limitations, and any relevant artifact identifiers.

## Validation Scripts

AI assets should be validated for frontmatter, required sections, naming, secrets, raw-data examples, and required evidence-rule language.

## Handoffs

Future handoffs:

- analyst -> config architect
- analyst -> report builder
- analyst -> validation reviewer
- analyst -> monitoring analyst
- analyst -> engineer

Do not implement all handoffs until real usage supports them.
