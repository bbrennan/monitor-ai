# Mandos-AI Full Design Document v3

**Status:** Draft  
**Purpose:** High-level architecture and design guidance for Mandos-AI.


## Implementation Note for the Development AI

These documents intentionally avoid hardcoding Mandos method names, object schemas, table names, report APIs, and persistence-layer details. The development AI implementing this work must inspect the current Mandos codebase and map these designs to the latest available APIs, config models, reporting interfaces, result objects, persistence objects, and tests.

The docs are authoritative about **goals, workflows, evidence rules, user experience, and architectural boundaries**. The current repo is authoritative about **exact implementation details**.


## Executive Summary

Mandos-AI is an internal, evidence-aware GitHub Copilot customization package for Mandos. Its first job is to accelerate adoption: help model owners document their models, set up Mandos correctly, interpret generated reports, prepare validation summaries, and reduce alert fatigue. Its long-term job is to query approved Mandos evidence through controlled tools and produce model-health explanations grounded in sourceable facts.

Mandos-AI should not begin as a large multi-agent platform. It should begin with one strong starter agent, a clear Model Knowledge Pack standard, reusable skills, prompt files, and validation scripts. MCP and specialized agents should be introduced only after the foundational workflows prove useful.

Product thesis:

> Mandos produces evidence. Mandos-AI explains evidence using model-specific context and disciplined source rules.


## Mandos-AI Evidence Doctrine

Mandos-AI may reason from general knowledge, but it must not report model-specific facts from memory.

Core rules:

```text
No metric -> no claim.
No source -> no fact.
No generated or persisted evidence -> no production conclusion.
```

Model-specific facts include metric values, metric definitions, thresholds, quality rules, baseline definitions, target definitions, score meanings, model ownership facts, run conclusions, issue counts, validation conclusions, and segment findings.

Mandos-AI should classify important statements as:

```text
FACT
A sourced observation from a model doc, active config, current code definition, generated report/result artifact, approved persisted evidence, or user-provided artifact.

INTERPRETATION
Reasoned explanation of what the facts likely mean.

RECOMMENDATION
Suggested next action, investigation path, remediation, or validation note.
```


## Source Model: Context, Policy, Evidence, Implementation

Mandos-AI must separate source types:

| Source Class | Role | Examples | Use For |
|---|---|---|---|
| Model Knowledge Pack | Domain context | Markdown docs, Confluence-derived docs | why the model matters, target meaning, business usage, known limitations |
| Active configs/contracts | Policy | current Mandos config, quality policies, segment config | intended rules, monitored fields, expected behavior |
| Generated Mandos outputs | Observed evidence | report artifacts, result objects, notebook outputs | what happened in a run or validation exercise |
| Approved persisted evidence | Historical/operational evidence | current Mandos persistence layer as implemented | persisted issues, baselines, historical evidence if available |
| Current Mandos code | Implementation truth | metric functions, report code, validators | how metrics/APIs/tools behave |
| User ad hoc input | Temporary context | chat, notes, clarifications | draft assumptions until formalized |

Clean operating rule:

```text
Markdown docs explain why it matters.
Configs explain what rules apply.
Mandos tools/outputs explain what happened.
Code explains how it is computed.
Mandos-AI explains what it means.
```

If sources conflict, Mandos-AI must not resolve the conflict silently. It should identify the conflict and ask for resolution or mark the conclusion as unsupported.


## Current Adoption Reality

Current reality driving the design:

- No model has fully launched on Mandos yet.
- Zuul 2.0 is preparing to become the first serious launch candidate.
- The Zuul team has used generated Mandos reporting for pre-release validation.
- Most users are still learning how to set up Mandos.
- Model documentation exists but is inconsistent across teams and Confluence pages.
- The development AI will have access to the latest Mandos repo and must inject exact API details.

Therefore, Mandos-AI v0.1 should focus on onboarding, documentation, setup guidance, report explanation, and validation support.


## Core Product Pillars

### 1. Setup Coach

Help users understand the Mandos onboarding path, baseline concepts, quality policies, segmentation, setup artifacts, and report generation.

### 2. Model Knowledge Pack Creator

Guide model owners through a structured intake process and create standardized Markdown artifacts that capture domain context.

### 3. Report Explainer and Validation Companion

Interpret generated Mandos reports/result artifacts and prepare validation-ready summaries with sourced facts, interpretations, recommendations, limitations, and open questions.

### 4. Alert Triage Analyst

Reduce alert fatigue by classifying findings as Action Required, Watchlist, Informational, or Suppressed / Likely Noise.

### 5. Custom Reporting and Visualization Builder

Create audience-specific report outlines, chart recommendations, and report templates beyond the standard report output.

### 6. Historical Monitoring Analyst

Future capability: answer trend, recurrence, and “what changed?” questions once approved persisted history is available.

### 7. Controlled Tooling / MCP

Future capability: allow Mandos-AI to retrieve approved evidence and execute safe read-only analysis tools through MCP or equivalent controlled tooling.


## GitHub Copilot Customization Architecture

Mandos-AI should be a layered Copilot customization package, not one giant prompt.

Recommended structure:

```text
.github/
  copilot-instructions.md
  agents/
    mandos-analyst.agent.md
    mandos-config-architect.agent.md
    mandos-report-builder.agent.md
    mandos-validation-reviewer.agent.md
    mandos-monitoring-analyst.agent.md
    mandos-engineer.agent.md
  prompts/
    mandos-create-model-knowledge-pack.prompt.md
    mandos-review-model-knowledge-pack.prompt.md
    mandos-create-setup-scaffold.prompt.md
    mandos-review-setup.prompt.md
    mandos-explain-report.prompt.md
    mandos-triage-alerts.prompt.md
    mandos-custom-report.prompt.md
    mandos-validation-summary.prompt.md
  skills/
    mandos-model-knowledge-pack/SKILL.md
    mandos-setup/SKILL.md
    mandos-baseline-design/SKILL.md
    mandos-feature-rules/SKILL.md
    mandos-segmentation/SKILL.md
    mandos-report-explainer/SKILL.md
    mandos-alert-triage/SKILL.md
    mandos-custom-reporting/SKILL.md
    mandos-validation-evidence/SKILL.md
    mandos-mcp-evidence-querying/SKILL.md
scripts/
  validate_ai_assets.py
  build_ai_catalog.py
templates/
  model_knowledge_pack/
  reports/
  charts/
```

Start with `.github/copilot-instructions.md`, `mandos-analyst.agent.md`, Model Knowledge Pack templates, and a small set of skills/prompts. Add other agents later only after usage justifies the split.


## Model Knowledge Pack

Each onboarded model should have a standardized Model Knowledge Pack. This can live in Git, Confluence, or both, but the structure should remain consistent.

Minimum required artifacts:

1. `model_card.md`
2. `business_context.md`
3. `scored_population.md`
4. `data_sources.md`
5. `target_definition.md`
6. `score_definition.md`
7. `feature_inventory.md`
8. `feature_engineering.md`
9. `preprocessing.md`
10. `quality_policy.md`
11. `baseline_definition.md`
12. `segmentation_strategy.md`
13. `monitoring_plan.md`
14. `proxy_metrics.md` when applicable
15. `known_limitations.md`
16. `validation_context.md`
17. `open_questions.md`

Every doc should include metadata:

```yaml
---
model_id: ""
model_version: ""
document_type: ""
status: "draft"
owner: ""
last_updated: ""
source: "model_owner_input"
reviewed_by: ""
review_status: "not_reviewed"
---
```

Docs should support Mandos-AI reasoning, but draft docs should not be treated as production truth.


## Guided Model Owner Intake

Mandos-AI should guide users through documentation and setup in stages:

1. Model identity
2. Business purpose
3. Scored population and grain
4. Target and score definition
5. Data sources
6. Features and preprocessing
7. Quality policy and critical features
8. Baseline and segmentation
9. Monitoring plan and proxy metrics
10. Known limitations
11. Validation context
12. Open questions and review status

The agent should not ask for everything at once. It should capture information section by section, label assumptions, and generate draft artifacts with missing-information checklists.


## Report Explanation and Validation Evidence

Mandos-AI should help users turn generated Mandos outputs into validation-ready summaries.

Report explanation should include:

- source artifacts used
- facts from generated outputs/config/docs
- interpretations
- recommendations
- action-required findings
- watchlist findings
- informational findings
- suppressed/likely-noise findings
- known limitations
- open questions
- validation-ready summary

Mandos-AI must not invent values from a report it has not seen.


## Alert Triage Design

Mandos-AI should classify findings using materiality and persistence, not raw severity alone.

Triage categories:

- Action Required
- Watchlist
- Informational
- Suppressed / Likely Noise

Triage factors:

- severity
- persistence
- magnitude
- distance from configured threshold where available
- affected volume
- segment importance
- feature importance
- known model limitations
- business decision relevance
- whether multiple findings share a root cause
- whether finding is new, recurring, improving, or worsening

Suppressed findings must remain visible in an appendix or explicit list with rationale.


## Custom Reporting and Visualization

Custom reporting should be audience-specific and evidence-grounded. It does not replace the standard built-in Mandos report.

Supported report modes:

- Executive Summary
- Model Validation Evidence Pack
- Model Owner Deep Dive
- Alert Triage Report
- Drift Investigation Report
- Data Quality Investigation Report
- Performance / Proxy Monitoring Report

Workflow:

1. identify audience and purpose
2. inventory available evidence
3. propose outline
4. propose chart set
5. generate script/notebook/template using current Mandos APIs
6. label facts and unsupported claims
7. include evidence appendix


## MCP and Controlled Tools

MCP is a future capability. It should be introduced only after the documentation, report explanation, and triage workflows are working.

Initial MCP should be read-only and evidence-focused. It should not provide arbitrary SQL, broad raw data access, or write access.

Tool tiers:

- Tier 1: read-only evidence/config/artifact retrieval
- Tier 2: analysis tools such as compare/summarize/triage over approved evidence
- Tier 3: write/official actions requiring explicit confirmation and audit logging

Every tool output should include provenance metadata so Mandos-AI can label facts accurately.


## Future Agent Roster

Start with one agent:

- `mandos-analyst`

Future agents, only if needed:

- `mandos-config-architect` for setup/config/policy review
- `mandos-report-builder` for custom reports/charts
- `mandos-validation-reviewer` for evidence quality and validation readiness
- `mandos-monitoring-analyst` for historical evidence and trend questions
- `mandos-engineer` for codebase implementation and tests

Do not split prematurely. Tool permissions should become narrower as agents specialize.


## Governance and Conflict Handling

Mandos-AI should track document status and source confidence.

Review statuses:

- draft
- model_owner_reviewed
- validation_reviewed
- production_approved
- deprecated

If a config, model doc, generated report, and code definition conflict, Mandos-AI should identify the conflict and avoid unsupported conclusions.

Example:

```text
The model documentation says the target has a 12-month observation window, but the active config references a different target concept. I cannot treat the target definition as settled until this mismatch is resolved.
```


## Success Measures

Adoption:

- number of model owners using guided onboarding
- number of completed Model Knowledge Packs
- reduction in repeated setup questions
- time to first successful report/result artifact

Documentation quality:

- completeness of required docs
- number of open questions
- number of source conflicts identified
- review status distribution

Report/triage quality:

- number of reports explained
- number of validation summaries generated
- user agreement with alert triage
- reduction in perceived alert fatigue

Future tooling:

- safe tool calls
- no unauthorized raw data exposure
- source metadata attached to facts
