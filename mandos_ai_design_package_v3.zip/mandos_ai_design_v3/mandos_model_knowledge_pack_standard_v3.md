# Mandos Model Knowledge Pack Standard v3

**Status:** Draft  
**Purpose:** Standardized model-specific documentation for Mandos-AI.


## Implementation Note for the Development AI

These documents intentionally avoid hardcoding Mandos method names, object schemas, table names, report APIs, and persistence-layer details. The development AI implementing this work must inspect the current Mandos codebase and map these designs to the latest available APIs, config models, reporting interfaces, result objects, persistence objects, and tests.

The docs are authoritative about **goals, workflows, evidence rules, user experience, and architectural boundaries**. The current repo is authoritative about **exact implementation details**.

## Source Model: Context, Policy, Evidence, Implementation

Mandos-AI must separate source types:

| Source Class | Role | Examples | Use For |
|---|---|---|---|
| Model Knowledge Pack | Domain context | Markdown docs, Confluence-derived docs | why the model matters, target meaning, business usage, known limitations |
| Active configs/contracts | Policy | current Mandos config, quality policies, segment config | intended rules, monitored fields, expected behavior |
| Generated Mandos outputs | Observed evidence | report artifacts, result objects, notebook outputs | what happened in a run or validation exercise |
| Approved persisted evidence | Historical/operational evidence | current Mandos persistence layer as implemented | persisted issues, baselines, historical evidence if available |
| Current Mandos code | Implementation truth | metric functions, report code, validators | how metrics/APIs/tools behave |
| User ad hoc input | Temporary context | chat, notes, clarifications | draft assumptions until formalized |

Clean operating rule:

```text
Markdown docs explain why it matters.
Configs explain what rules apply.
Mandos tools/outputs explain what happened.
Code explains how it is computed.
Mandos-AI explains what it means.
```

If sources conflict, Mandos-AI must not resolve the conflict silently. It should identify the conflict and ask for resolution or mark the conclusion as unsupported.

## Required Artifacts

Use this structure in Git or mirror it in Confluence:

```text
models/{model_id}/model_knowledge_pack/
  README.md
  model_card.md
  business_context.md
  scored_population.md
  data_sources.md
  target_definition.md
  score_definition.md
  feature_inventory.md
  feature_engineering.md
  preprocessing.md
  quality_policy.md
  baseline_definition.md
  segmentation_strategy.md
  monitoring_plan.md
  proxy_metrics.md
  known_limitations.md
  validation_context.md
  open_questions.md
```

## Standard Frontmatter

```yaml
---
model_id: ""
model_version: ""
document_type: ""
status: "draft"
owner: ""
last_updated: ""
source: "model_owner_input"
reviewed_by: ""
review_status: "not_reviewed"
---
```

Allowed statuses: draft, model_owner_reviewed, validation_reviewed, production_approved, deprecated.

## Standard Sections

Every doc should include:

```markdown
# Title

## Purpose

## Required Facts

## Business / Technical Explanation

## Monitoring Implications

## Open Questions

## Review Checklist
```

## Must-Have Information

### Model Card

- model name
- model ID/version
- business area
- model owner
- technical owner
- deployment status
- validation status
- model type / usage
- monitoring cadence

### Business Context

- business problem solved
- process or decision supported
- downstream consumers
- downstream actions
- business consequence of degradation

### Scored Population

- entity grain
- included population
- excluded population
- eligibility rules
- expected population changes
- known edge cases

### Data Sources

- source systems or data products
- grain
- refresh cadence
- critical fields supplied
- join keys if known
- data owner if known
- known upstream dependencies and risks

### Target Definition

- target concept/name
- plain-English definition
- positive class if classification
- observation window
- label delay
- exclusions
- leakage risks
- whether labels are available at monitoring time

### Score Definition

- score/output name
- score meaning
- score range
- directionality
- score bands/cutoffs if applicable
- downstream decision usage

### Feature Inventory / Feature Engineering / Preprocessing

- feature groups
- critical features
- source domains
- business meaning of critical features
- derived logic
- missing value handling
- imputation
- scaling/standardization
- encoding
- capping/flooring
- binning
- sentinel values
- edge cases

### Quality Policy

- nullable expectations
- valid ranges
- valid categories
- binary flag expectations
- known sentinel values
- imputation expectations
- cap/floor expectations
- critical feature rules
- note that active configs are enforcement source

### Baseline Definition

- baseline population
- time window
- reason chosen
- exclusions
- reference type: training/validation/champion/production/etc.
- refresh policy
- caveats

### Segmentation Strategy

- critical segments
- business reason for each
- high-volume segments
- low-volume/noisy segments
- validation/governance segments
- materiality notes

### Monitoring Plan

- cadence
- pre-launch expectations
- production expectations
- data quality checks
- drift checks
- performance checks if labels exist
- proxy metrics if labels are delayed
- escalation expectations
- materiality guidance

### Proxy Metrics

- proxy names/concepts
- why each matters
- expected directionality
- concerning movement
- monitored segments
- limitation that proxies are early-warning evidence, not definitive performance proof

### Known Limitations

- label delay
- small segment noise
- data source instability
- feature limitations
- seasonality
- policy/strategy changes
- validation caveats

### Validation Context

- validation status
- required evidence
- pre-launch acceptance expectations
- open validation questions
- prior validation feedback if available
- claims Mandos-AI should avoid without evidence

### Open Questions

- question
- owner
- priority
- target resolution date if known
- launch/readiness impact

## Guided Intake Flow

Mandos-AI should ask for this information in stages, not all at once:

1. model identity
2. business purpose
3. scored population
4. target and score
5. data sources
6. features and preprocessing
7. quality policy
8. baseline and segmentation
9. monitoring plan and proxy metrics
10. known limitations and validation context
11. open questions

## Readiness Checklist

A pack is not ready unless required docs exist, frontmatter is complete, target/score/baseline/segments are clear, limitations are documented, open questions are listed, and draft assumptions are labeled.
